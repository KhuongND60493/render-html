$("a[class=dropdown-item]").click(function () {
  $(this).parents(".dropdown").find('.btn').html($(this).text() + ' <i class="fas fa-angle-down"></i>');
  $(this).parents(".dropdown").find('.btn').val($(this).data('value'));
});
$('.btn-sidebar').click(function (e) {
  e.preventDefault();
  var isToggled = $(this).parents('.wrapper').hasClass('toggled');
  $(this).parents('.wrapper').toggleClass("toggled");
  if (!isToggled)
    $('#under-background').css('display', 'block');
  else
    $('#under-background').css('display', 'none');
});

$('#under-background').click(function () {
  $('.wrapper').toggleClass("toggled");
  $('#under-background').css('display', 'none');

})

$('#under-background-setting').click(function () {
  document.getElementById("mySetting").style.width = "0";
  $('#under-background-setting').css('display', 'none');
})
function openNav() {
  document.getElementById("mySetting").style.width = "250px";
  $('#under-background-setting').css('display', 'block');
}

function closeNav() {
  document.getElementById("mySetting").style.width = "0";
  $('#under-background-setting').css('display', 'none');
}


$(".input-search>input").after(' <div class="input-search-border"></div>');
$(".input-search>input").after('<div class="input-group-append"><button class="btn btn-outline-secondary" type="button" > <i class="fa fa-times" style="font-size:20px"></i></button></div>');
$('.noUi-handle').on('click', function () {
  $(this).width(50);
});
function create_slider_range(item_range, callBack) {
  var minmax = $(item_range).data('minmax');
  if (typeof (minmax) != undefined) {
    var arrayMinMax = minmax.split("-");
    if (arrayMinMax.length == 2) {
      var init = $(item_range).data('init');
      var step = $(item_range).data('step') ? parseInt($(item_range).data('step')) : 1;
      var arrayInit = init.split("-");
      var rangeSlider = document.createElement("div");
      noUiSlider.create(rangeSlider, {
        start: [parseInt(arrayInit[0]), parseInt(arrayInit[1])],
        step: step,
        range: {
          'min': [parseInt(arrayMinMax[0])],
          'max': [parseInt(arrayMinMax[1])]
        },
        format: wNumb({ decimals: 0, thousand: ',' }),
        connect: true
      });
      $(item_range).append(rangeSlider);
      rangeSlider.noUiSlider.on('update', function (values, handle) {
        callBack(values[0], values[1]);
      });
    }

  }
}
function mapping_view(view) {
  var id = view[0].id;
  var view_map = $('.mapping_view[data-show=' + id + ']');
  view_map.html(view.html());
  view.css('display', 'none');
  // $('#mydiv1').clone().appendTo('#mydiv2');
}

$(function () {
  if (typeof (Storage) == "undefined" || sessionStorage.getItem("mode-theme") == null) {
    sessionStorage.setItem("mode-theme", "light");
  }
  if (typeof (Storage) == "undefined" || sessionStorage.getItem("mode-color") == null) {
    sessionStorage.setItem("mode-color", "orange-skin");
  }

  var mode = sessionStorage.getItem("mode-theme");
  document.body.setAttribute('data-theme', mode);
  $('#themeSwitch').attr('checked', (mode == 'dark'));
  document.body.setAttribute('class', sessionStorage.getItem("mode-color"));
})
document.getElementById('themeSwitch').addEventListener('change', function (event) {
  (event.target.checked) ? document.body.setAttribute('data-theme', 'dark') : document.body.removeAttribute('data-theme');
  sessionStorage.setItem("mode-theme", (event.target.checked) ? 'dark' : 'light');
});

function chooseModeColor(color) {
  document.body.setAttribute('class', color);
  sessionStorage.setItem("mode-color", color);
}

function goToByScroll(id) {
  // Reove "link" from the ID
  id = id.replace("link", "");
  // Scroll
  $('#content-scroll').animate({
    scrollTop: $("#" + id).offset().top
  },
    'slow');
}

$("#abcclass > ul > li > a").click(function (e) {
  // Prevent a page reload when a link is pressed
  e.preventDefault();
  console.log('aaaa');
  // Call the scroll function
  goToByScroll($(this).attr("id"));
});